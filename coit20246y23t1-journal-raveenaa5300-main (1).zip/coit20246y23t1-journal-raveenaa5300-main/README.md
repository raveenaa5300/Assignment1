# COIT20246 Networking and Cyber Security Journal

- Student Name: Raveena
- Student ID: 12221070
- Campus: Sydney
- Tutor: Md Hossain

## Weekly Journal Entries
1. [Computer Systems and Applications](./week01.md)
![student](https://user-images.githubusercontent.com/127452018/227778711-333c5475-e3cf-4131-ba5e-aef1f53093e4.PNG)
![student1](https://user-images.githubusercontent.com/127452018/227778764-872893c7-d1f0-4e94-9f59-972b7849f6a7.PNG)
![student2](https://user-images.githubusercontent.com/127452018/227778685-ec31f21e-9b8d-43a9-a228-b9a45ac7a8ce.PNG)
![student3](https://user-images.githubusercontent.com/127452018/227778807-c8b88749-5fce-4936-bba3-86ed78aa9919.PNG)
![student4](https://user-images.githubusercontent.com/127452018/227778866-70939749-d188-4595-ac70-6923435b068e.PNG)
![student5](https://user-images.githubusercontent.com/127452018/227778893-4b0cad16-2db9-4be2-a94c-d9610c578227.PNG)
![system](https://user-images.githubusercontent.com/127452018/227778952-ac5e9fb2-4988-4bae-8886-b84b504ee024.PNG)
![system1](https://user-images.githubusercontent.com/127452018/227778971-ca9f13d0-fd12-461f-a163-881bf37a5375.PNG)
![system2](https://user-images.githubusercontent.com/127452018/227778981-16eddc6c-7aa9-49e3-982f-226fc9ab17da.PNG)
![system3](https://user-images.githubusercontent.com/127452018/227778996-b6cd22d5-787c-4006-ac72-3ab0070ff1e0.PNG
https://drive.google.com/open?id=1ZruVueyc3kF3XYpJVGPGF_DU5N0HkraA&usp=drive_copy
https://drive.google.com/open?id=1U0Yc-WDg7-RbNpZw9HT9yBLMBN_6_Wjd&usp=drive_copy
https://drive.google.com/open?id=14p2PLhVdfE16UTsG4ASskaRwhv3DzpRd&usp=drive_copy
https://drive.google.com/open?id=1JajJVd12jQqseROZ2l9xvrni5kiFkWrN&usp=drive_copy
https://drive.google.com/open?id=1AdPiuzci0YVjH6e-i3t4sCXHSVmlRbgj&usp=drive_copy
https://drive.google.com/open?id=1Dkk8MLCYqzoYEHF9wfOHiz0-AsWPXuGr&usp=drive_copy
https://drive.google.com/open?id=1IupgO0aG6SsD7f5LwVqX4UQB4lmGAEfX&usp=drive_copy
https://drive.google.com/open?id=1gNAfAu8dl3YBItAzQj-CigAnpZLR0vFb&usp=drive_copy
https://drive.google.com/open?id=1BQke3W3kSNbuHQaFihOsyFHn9QV-WWb0&usp=drive_copy
https://drive.google.com/open?id=1XezM9fY1V3UFoXEaYxfwfPmJJ-_YdV1I&usp=drive_copy
https://drive.google.com/open?id=1h2CRMYgv_5tt0fwDwvqbTp_lvm-wl5kp&usp=drive_copy
https://drive.google.com/open?id=1RLhcqMoPof9iWgPlLMU27l2dVb3aalqK&usp=drive_copy
https://drive.google.com/open?id=1FxuVEYwC3l7Mj869ao08Hk135JNXfXC1&usp=drive_copy
https://drive.google.com/open?id=1o8hdMYeu5w0cJEb8VcrmW1maPvlAB_NG&usp=drive_copy
https://drive.google.com/open?id=1JdLiFaHv6hNE43hMrBYij9qbCmzYyI0m&usp=drive_copy
1. [Computer Networks and the Internet](./week02.md)
https://drive.google.com/open?id=1TwoZL-uJRX9i6eQTo-5V4hLh0vRbZUbV&usp=drive_copy
https://drive.google.com/open?id=1VHufczc_PVy2hvqLgL_laJ31DI29SD7D&usp=drive_copy

1. [Network Technologies](./week03.md)
https://drive.google.com/open?id=1gNAfAu8dl3YBItAzQj-CigAnpZLR0vFb&usp=drive_copy
https://drive.google.com/open?id=1CyH8kfq1YLGtiHsJ2W4XLbHjwVbB2bFB&usp=drive_copy
https://drive.google.com/open?id=1-CdMXgiSbog9YWLRltGoIjtr0Y4sQXr4&usp=drive_copy
https://drive.google.com/open?id=1xE2XfrsE5TQTxtDawioem-x2uUACJ_zg&usp=drive_copy
1. ...

## Quick Links
- [Moodle](https://moodle.cqu.edu.au/course/view.php?id=48862)
- [Markdown syntax](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax)
- [PowerShell help](https://learn.microsoft.com/en-us/powershell/)
