# Week 1 | Computer Systems and Applications
## Task 1. View Your Computer Information
Ans.My answer is specification of my computer.
For example: Windows 10 Home(64-bit)
RAM:2GB
CPU:8700
## Task 2. Deploy Linux Web Server in VirtualBox
Ans.I uploaded a picture related to this.
## Weekly Reflection
Ans.This week i learnt how to find my computer specification,RAM,CPU and many more.I learnt how we can use powershell commands nd linux commands. These commands are very useful. 
## Extra Resources

